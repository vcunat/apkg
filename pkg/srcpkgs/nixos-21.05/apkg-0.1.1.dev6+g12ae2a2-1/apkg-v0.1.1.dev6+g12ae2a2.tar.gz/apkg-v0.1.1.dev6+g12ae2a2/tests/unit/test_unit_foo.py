def test_unit_dummy():
    print("dummy unit test")
