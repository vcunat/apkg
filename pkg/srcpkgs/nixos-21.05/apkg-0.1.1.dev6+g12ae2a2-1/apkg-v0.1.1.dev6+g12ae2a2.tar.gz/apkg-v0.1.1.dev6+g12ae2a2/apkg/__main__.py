from apkg.cli import main


main()
