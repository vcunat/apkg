# current apkg version
from ._version import __version__  # noqa


# current apkg compatibility level
COMPAT_LEVEL = 1
